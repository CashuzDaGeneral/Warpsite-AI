import React from 'react';
import { motion } from 'framer-motion';

const plans = [
  {
    name: 'Starter',
    price: '$29',
    features: [
      'Basic AI website generation',
      '5 pages per project',
      'Basic templates',
      'Community support'
    ]
  },
  {
    name: 'Professional',
    price: '$79',
    features: [
      'Advanced AI co-creation',
      'Unlimited pages',
      'Premium templates',
      'Priority support',
      'Custom domain'
    ]
  },
  {
    name: 'Enterprise',
    price: 'Custom',
    features: [
      'Full AI capabilities',
      'Custom integrations',
      'Dedicated support',
      'SLA guarantee',
      'Advanced analytics'
    ]
  }
];

export function PricingPage() {
  return (
    <div className="py-24 px-4 bg-gradient-to-br from-[#001533] to-[#0066ff]">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h1 className="text-4xl font-bold text-white mb-4">Simple, Transparent Pricing</h1>
          <p className="text-xl text-gray-200">Choose the plan that best fits your needs</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {plans.map((plan, index) => (
            <motion.div
              key={plan.name}
              className="bg-white rounded-lg shadow-xl p-8"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.2 }}
            >
              <h3 className="text-2xl font-bold mb-4">{plan.name}</h3>
              <p className="text-4xl font-bold mb-6">{plan.price}</p>
              <ul className="space-y-4 mb-8">
                {plan.features.map((feature) => (
                  <li key={feature} className="flex items-center">
                    <svg className="w-5 h-5 text-green-500 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                    </svg>
                    {feature}
                  </li>
                ))}
              </ul>
              <button className="w-full bg-[#00c2ff] text-white py-3 rounded-lg hover:bg-[#00a0ff] transition-colors">
                Get Started
              </button>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}