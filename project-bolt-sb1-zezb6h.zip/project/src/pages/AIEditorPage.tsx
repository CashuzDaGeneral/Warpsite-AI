import React from 'react';
import { AIWorkspace } from '../components/ai-editor/AIWorkspace';
import { AIToolbar } from '../components/ai-editor/AIToolbar';
import { AIPreview } from '../components/ai-editor/AIPreview';

export function AIEditorPage() {
  return (
    <div className="min-h-screen bg-gray-50 pt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <h1 className="text-3xl font-bold mb-8">AI Website Editor</h1>
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          <div className="lg:col-span-3">
            <AIToolbar />
          </div>
          <div className="lg:col-span-6">
            <AIWorkspace />
          </div>
          <div className="lg:col-span-3">
            <AIPreview />
          </div>
        </div>
      </div>
    </div>
  );
}