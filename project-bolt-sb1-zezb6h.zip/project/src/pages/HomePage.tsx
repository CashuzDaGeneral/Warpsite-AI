import React from 'react';
import { Hero } from '../components/home/Hero';
import { Features } from '../components/home/Features';
import { Integrations } from '../components/home/Integrations';
import { Newsletter } from '../components/home/Newsletter';

export function HomePage() {
  return (
    <div className="min-h-screen bg-white">
      <Hero />
      <Features />
      <Integrations />
      <Newsletter />
    </div>
  );
}