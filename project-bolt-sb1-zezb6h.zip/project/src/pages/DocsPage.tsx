import React from 'react';
import { motion } from 'framer-motion';
import { DocsSidebar } from '../components/docs/DocsSidebar';
import { DocsContent } from '../components/docs/DocsContent';

export function DocsPage() {
  return (
    <div className="min-h-screen bg-gray-50 pt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          <div className="lg:col-span-1">
            <DocsSidebar />
          </div>
          <div className="lg:col-span-3">
            <DocsContent />
          </div>
        </div>
      </div>
    </div>
  );
}