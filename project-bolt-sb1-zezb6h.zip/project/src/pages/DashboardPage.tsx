import React from 'react';
import { motion } from 'framer-motion';

export function DashboardPage() {
  return (
    <div className="min-h-screen bg-gray-50 pt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5 }}
        >
          <h1 className="text-3xl font-bold mb-8">Dashboard</h1>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h2 className="text-xl font-semibold mb-4">Recent Projects</h2>
              <div className="space-y-4">
                {/* Project list would be dynamically populated */}
                <p className="text-gray-600">No projects yet</p>
              </div>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h2 className="text-xl font-semibold mb-4">AI Credits</h2>
              <div className="text-3xl font-bold text-[#0066ff]">1,000</div>
              <p className="text-gray-600">Available credits</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h2 className="text-xl font-semibold mb-4">Quick Actions</h2>
              <div className="space-y-2">
                <button className="w-full bg-[#00c2ff] text-white py-2 rounded hover:bg-[#00a0ff] transition-colors">
                  New Project
                </button>
                <button className="w-full border border-[#00c2ff] text-[#00c2ff] py-2 rounded hover:bg-gray-50 transition-colors">
                  Import Template
                </button>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}