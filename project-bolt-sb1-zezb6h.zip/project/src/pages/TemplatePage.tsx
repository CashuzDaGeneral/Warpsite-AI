import React from 'react';
import { useParams } from 'react-router-dom';
import { TemplateRenderer } from '../components/template/TemplateRenderer';

export function TemplatePage() {
  const { templateId } = useParams();
  
  return (
    <div className="template-page">
      <TemplateRenderer 
        templatePath={`/templates/${templateId}.html`}
        data={{
          title: 'Dynamic Title',
          description: 'Dynamic Description'
        }}
      />
    </div>
  );
}