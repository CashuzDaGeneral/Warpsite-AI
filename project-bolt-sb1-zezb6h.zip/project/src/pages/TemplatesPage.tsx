import React from 'react';
import { motion } from 'framer-motion';

const templates = [
  {
    name: 'Business',
    description: 'Professional templates for businesses and organizations',
    category: 'Business',
    thumbnailUrl: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&q=80&w=300&h=200'
  },
  {
    name: 'Portfolio',
    description: 'Showcase your work with elegant portfolio templates',
    category: 'Creative',
    thumbnailUrl: 'https://images.unsplash.com/photo-1545665277-5937489579f2?auto=format&fit=crop&q=80&w=300&h=200'
  },
  {
    name: 'E-commerce',
    description: 'Start selling online with our e-commerce templates',
    category: 'E-commerce',
    thumbnailUrl: 'https://images.unsplash.com/photo-1472851294608-062f824d29cc?auto=format&fit=crop&q=80&w=300&h=200'
  }
];

export function TemplatesPage() {
  return (
    <div className="min-h-screen bg-gray-50 pt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5 }}
        >
          <div className="flex justify-between items-center mb-8">
            <h1 className="text-3xl font-bold">Templates</h1>
            <div className="flex space-x-4">
              <select className="border rounded-md px-4 py-2">
                <option>All Categories</option>
                <option>Business</option>
                <option>Creative</option>
                <option>E-commerce</option>
              </select>
              <button className="bg-[#00c2ff] text-white px-4 py-2 rounded-md hover:bg-[#00a0ff] transition-colors">
                Import Template
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {templates.map((template) => (
              <motion.div
                key={template.name}
                className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow"
                whileHover={{ y: -5 }}
              >
                <img
                  src={template.thumbnailUrl}
                  alt={template.name}
                  className="w-full h-48 object-cover"
                />
                <div className="p-6">
                  <span className="text-sm text-[#0066ff] font-medium">{template.category}</span>
                  <h3 className="text-xl font-semibold mt-2 mb-2">{template.name}</h3>
                  <p className="text-gray-600 mb-4">{template.description}</p>
                  <button className="w-full bg-gray-50 text-gray-800 px-4 py-2 rounded-md hover:bg-gray-100 transition-colors">
                    Use Template
                  </button>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </div>
  );
}