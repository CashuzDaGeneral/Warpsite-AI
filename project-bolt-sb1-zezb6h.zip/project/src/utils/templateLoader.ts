import { useState, useEffect } from 'react';

export const useTemplate = (templatePath: string) => {
  const [template, setTemplate] = useState<string>('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const loadTemplate = async () => {
      try {
        const response = await fetch(templatePath);
        if (!response.ok) {
          throw new Error(`Failed to load template: ${response.statusText}`);
        }
        const html = await response.text();
        setTemplate(html);
        setLoading(false);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to load template');
        setLoading(false);
      }
    };

    loadTemplate();
  }, [templatePath]);

  return { template, loading, error };
};