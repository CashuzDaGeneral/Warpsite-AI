import React from 'react';
import { Link } from 'react-router-dom';

export function Footer() {
  return (
    <footer className="bg-[#001533] text-white py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <h3 className="text-lg font-semibold mb-4">Product</h3>
            <ul className="space-y-2">
              <li><Link to="/features" className="hover:text-[#00c2ff]">Features</Link></li>
              <li><Link to="/pricing" className="hover:text-[#00c2ff]">Pricing</Link></li>
              <li><Link to="/templates" className="hover:text-[#00c2ff]">Templates</Link></li>
            </ul>
          </div>
          <div>
            <h3 className="text-lg font-semibold mb-4">Resources</h3>
            <ul className="space-y-2">
              <li><Link to="/docs" className="hover:text-[#00c2ff]">Documentation</Link></li>
              <li><Link to="/tutorials" className="hover:text-[#00c2ff]">Tutorials</Link></li>
              <li><Link to="/blog" className="hover:text-[#00c2ff]">Blog</Link></li>
            </ul>
          </div>
          <div>
            <h3 className="text-lg font-semibold mb-4">Company</h3>
            <ul className="space-y-2">
              <li><Link to="/about" className="hover:text-[#00c2ff]">About</Link></li>
              <li><Link to="/contact" className="hover:text-[#00c2ff]">Contact</Link></li>
              <li><Link to="/careers" className="hover:text-[#00c2ff]">Careers</Link></li>
            </ul>
          </div>
          <div>
            <h3 className="text-lg font-semibold mb-4">Legal</h3>
            <ul className="space-y-2">
              <li><Link to="/privacy" className="hover:text-[#00c2ff]">Privacy Policy</Link></li>
              <li><Link to="/terms" className="hover:text-[#00c2ff]">Terms of Service</Link></li>
            </ul>
          </div>
        </div>
        <div className="mt-8 pt-8 border-t border-gray-700">
          <p className="text-center text-gray-400">© {new Date().getFullYear()} Warpsite AI. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}