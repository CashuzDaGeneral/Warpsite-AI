import React from 'react';
import { motion } from 'framer-motion';

export function DocsContent() {
  return (
    <motion.div
      className="bg-white rounded-lg shadow-md p-8"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
    >
      <h1 className="text-3xl font-bold mb-6">Introduction</h1>
      <p className="text-gray-600 mb-6">
        Welcome to the Warpsite AI documentation. This guide will help you understand how to use our AI-powered website generator effectively.
      </p>
      
      <h2 className="text-2xl font-bold mb-4">What is Warpsite AI?</h2>
      <p className="text-gray-600 mb-6">
        Warpsite AI is an advanced website generator that leverages artificial intelligence to streamline the process of designing, building, and deploying websites across multiple platforms.
      </p>

      <h2 className="text-2xl font-bold mb-4">Key Features</h2>
      <ul className="list-disc list-inside text-gray-600 space-y-2 mb-6">
        <li>AI-powered website generation</li>
        <li>Dynamic content creation</li>
        <li>Multi-platform deployment</li>
        <li>Integrated development environment</li>
        <li>Real-time collaboration</li>
      </ul>

      <div className="bg-gray-50 rounded-lg p-6 mb-6">
        <h3 className="text-lg font-semibold mb-2">Quick Start</h3>
        <p className="text-gray-600">
          To get started with Warpsite AI, follow these simple steps:
        </p>
        <ol className="list-decimal list-inside text-gray-600 mt-2">
          <li>Sign up for an account</li>
          <li>Create a new project</li>
          <li>Choose a template or start from scratch</li>
          <li>Use AI tools to customize your website</li>
          <li>Preview and deploy</li>
        </ol>
      </div>
    </motion.div>
  );
}