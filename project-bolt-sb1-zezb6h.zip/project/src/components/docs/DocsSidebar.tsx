import React from 'react';
import { Book, Code, Rocket, Lightbulb, Settings } from 'lucide-react';

const sections = [
  {
    title: 'Getting Started',
    icon: Rocket,
    items: ['Introduction', 'Quick Start', 'Installation']
  },
  {
    title: 'Core Concepts',
    icon: Lightbulb,
    items: ['AI Co-Creation', 'Templates', 'Components']
  },
  {
    title: 'API Reference',
    icon: Code,
    items: ['Authentication', 'Endpoints', 'WebSocket']
  },
  {
    title: 'Configuration',
    icon: Settings,
    items: ['Project Setup', 'Deployment', 'Custom Domains']
  }
];

export function DocsSidebar() {
  return (
    <div className="bg-white rounded-lg shadow-md p-4">
      <div className="flex items-center mb-6">
        <Book className="w-5 h-5 text-[#0066ff] mr-2" />
        <h2 className="text-lg font-semibold">Documentation</h2>
      </div>
      <div className="space-y-6">
        {sections.map((section) => (
          <div key={section.title}>
            <div className="flex items-center mb-2">
              <section.icon className="w-4 h-4 text-gray-600 mr-2" />
              <h3 className="font-medium">{section.title}</h3>
            </div>
            <ul className="space-y-2 ml-6">
              {section.items.map((item) => (
                <li key={item}>
                  <a
                    href={`#${item.toLowerCase().replace(/\s+/g, '-')}`}
                    className="text-gray-600 hover:text-[#0066ff] transition-colors"
                  >
                    {item}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>
    </div>
  );
}