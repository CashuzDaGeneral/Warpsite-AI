import React from 'react';
import { useTemplate } from '../../utils/templateLoader';

interface TemplateRendererProps {
  templatePath: string;
  data?: Record<string, any>;
}

export function TemplateRenderer({ templatePath, data }: TemplateRendererProps) {
  const { template, loading, error } = useTemplate(templatePath);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex items-center justify-center min-h-screen text-red-600">
        Error: {error}
      </div>
    );
  }

  // Process template with data if provided
  let processedTemplate = template;
  if (data) {
    Object.entries(data).forEach(([key, value]) => {
      const regex = new RegExp(`{{${key}}}`, 'g');
      processedTemplate = processedTemplate.replace(regex, String(value));
    });
  }

  return (
    <div 
      dangerouslySetInnerHTML={{ __html: processedTemplate }}
      className="template-content"
    />
  );
}