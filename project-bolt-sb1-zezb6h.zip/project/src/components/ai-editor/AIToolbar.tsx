import React from 'react';
import { Wand2, Layout, Image, Type, Code, Settings } from 'lucide-react';

const tools = [
  { icon: Layout, label: 'Layout' },
  { icon: Image, label: 'Media' },
  { icon: Type, label: 'Typography' },
  { icon: Code, label: 'Components' },
  { icon: Settings, label: 'Settings' }
];

export function AIToolbar() {
  return (
    <div className="bg-white rounded-lg shadow-md p-4">
      <div className="flex items-center mb-6">
        <Wand2 className="w-5 h-5 text-[#0066ff] mr-2" />
        <h2 className="text-lg font-semibold">AI Tools</h2>
      </div>
      <div className="space-y-2">
        {tools.map((Tool) => (
          <button
            key={Tool.label}
            className="w-full flex items-center p-3 rounded-md hover:bg-gray-50 transition-colors"
          >
            <Tool.icon className="w-5 h-5 text-gray-600 mr-3" />
            <span>{Tool.label}</span>
          </button>
        ))}
      </div>
    </div>
  );
}