import React from 'react';
import { motion } from 'framer-motion';

export function AIWorkspace() {
  return (
    <motion.div
      className="bg-white rounded-lg shadow-md p-6 min-h-[600px]"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
    >
      <div className="border-2 border-dashed border-gray-200 rounded-lg h-full flex items-center justify-center">
        <div className="text-center">
          <p className="text-gray-500 mb-4">Drag and drop elements or use AI suggestions</p>
          <button className="bg-[#00c2ff] text-white px-6 py-3 rounded-lg hover:bg-[#00a0ff] transition-colors">
            Generate Layout
          </button>
        </div>
      </div>
    </motion.div>
  );
}