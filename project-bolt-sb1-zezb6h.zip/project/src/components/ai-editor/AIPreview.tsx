import React from 'react';
import { Eye, Smartphone, Monitor, Tablet } from 'lucide-react';

const viewports = [
  { icon: Monitor, label: 'Desktop' },
  { icon: Tablet, label: 'Tablet' },
  { icon: Smartphone, label: 'Mobile' }
];

export function AIPreview() {
  return (
    <div className="bg-white rounded-lg shadow-md p-4">
      <div className="flex items-center mb-6">
        <Eye className="w-5 h-5 text-[#0066ff] mr-2" />
        <h2 className="text-lg font-semibold">Preview</h2>
      </div>
      <div className="flex justify-center space-x-4 mb-6">
        {viewports.map((View) => (
          <button
            key={View.label}
            className="p-2 rounded-md hover:bg-gray-50 transition-colors"
            title={View.label}
          >
            <View.icon className="w-5 h-5 text-gray-600" />
          </button>
        ))}
      </div>
      <div className="border rounded-lg h-[400px] bg-gray-50">
        {/* Preview content will be rendered here */}
      </div>
    </div>
  );
}