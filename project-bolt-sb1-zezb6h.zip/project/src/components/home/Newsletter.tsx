import React, { useState } from 'react';
import { motion } from 'framer-motion';

export function Newsletter() {
  const [email, setEmail] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    alert('Thanks for subscribing! We\'ll keep you updated.');
    setEmail('');
  };

  return (
    <div className="bg-[#001533] text-white py-16 px-8 text-center">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        <h2 className="text-3xl font-bold mb-4">Stay Updated</h2>
        <p className="mb-8">Subscribe to our newsletter for the latest updates and feature releases.</p>
        <form onSubmit={handleSubmit} className="max-w-md mx-auto">
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="Enter your email"
            className="w-full px-4 py-3 mb-4 rounded-lg text-gray-900"
            required
          />
          <button
            type="submit"
            className="w-full bg-[#00c2ff] text-white px-8 py-3 rounded-lg text-lg font-medium hover:bg-[#00a0ff] transition-colors"
          >
            Subscribe
          </button>
        </form>
      </motion.div>
    </div>
  );
}