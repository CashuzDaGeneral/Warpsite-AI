import React from 'react';
import { motion } from 'framer-motion';

export function Hero() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-[#001533] to-[#0066ff] text-white py-16 px-8 flex flex-col items-center text-center">
      <motion.img
        src="/Screenshot 2024-11-19 141516.png"
        alt="Warpsite logo"
        className="w-32 h-32 mb-8"
        animate={{ y: [-10, 0, -10] }}
        transition={{ 
          duration: 3,
          repeat: Infinity,
          ease: "easeInOut"
        }}
      />
      <h1 className="text-5xl font-bold mb-6">Warpsite AI</h1>
      <p className="max-w-3xl text-xl mb-12">
        A revolutionary AI-powered website generator that combines cutting-edge artificial intelligence with intuitive design tools. Create stunning, responsive websites across multiple platforms with the power of AI co-creation, advanced automation, and seamless deployment options.
      </p>
      <button className="bg-[#00c2ff] text-white px-8 py-4 rounded-lg text-lg font-medium hover:bg-[#00a0ff] transition-colors">
        Get Started
      </button>
    </div>
  );
}