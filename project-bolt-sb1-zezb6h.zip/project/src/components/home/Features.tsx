import React from 'react';
import { motion } from 'framer-motion';

const features = [
  {
    title: 'AI Co-Creation',
    description: 'Work alongside our advanced AI to design and develop your perfect website. The AI adapts in real-time to your preferences and needs.'
  },
  {
    title: 'Multi-Platform Deployment',
    description: 'Deploy your website across web, mobile apps, and Progressive Web Apps (PWAs) with seamless optimization for each platform.'
  },
  {
    title: 'Dynamic Content Generation',
    description: 'Generate high-quality content, including copy, images, and videos, powered by advanced AI algorithms.'
  },
  {
    title: '3D/4D Visuals',
    description: 'Create immersive interactive experiences with AI-generated 3D models and animated content.'
  }
];

export function Features() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-6xl mx-auto px-8 py-16">
      {features.map((feature, index) => (
        <motion.div
          key={feature.title}
          className="bg-white p-8 rounded-lg shadow-lg hover:shadow-xl transition-shadow"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: index * 0.1 }}
        >
          <h3 className="text-xl font-semibold mb-4">{feature.title}</h3>
          <p className="text-gray-600">{feature.description}</p>
        </motion.div>
      ))}
    </div>
  );
}