import React from 'react';
import { motion } from 'framer-motion';

const integrations = [
  {
    title: 'V0.dev',
    description: 'Frontend development inspiration and seamless component integration.'
  },
  {
    title: 'Relume',
    description: 'Import web frames and sitemaps for rapid development.'
  },
  {
    title: 'Figma',
    description: 'Design integration for enhanced workflow efficiency.'
  }
];

export function Integrations() {
  return (
    <div className="bg-[#f5f8ff] py-16 px-8 text-center">
      <h2 className="text-3xl font-bold mb-12">Streamline Your Process</h2>
      <div className="flex flex-wrap justify-center gap-8">
        {integrations.map((integration, index) => (
          <motion.div
            key={integration.title}
            className="bg-white p-6 rounded-lg w-64 hover:transform hover:scale-105 transition-transform"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: index * 0.2 }}
          >
            <h3 className="text-xl font-semibold mb-4">{integration.title}</h3>
            <p className="text-gray-600">{integration.description}</p>
          </motion.div>
        ))}
      </div>
    </div>
  );
}